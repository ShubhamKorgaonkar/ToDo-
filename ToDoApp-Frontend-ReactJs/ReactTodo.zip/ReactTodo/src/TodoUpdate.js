import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Form, Button, Container, Row, Col, Alert } from 'react-bootstrap';

function TodoUpdate() {
    const [todo, setTodo] = useState({});
    const { id } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        fetch(`http://localhost:5273/api/Todo/${id}`)
            .then(res => res.json())
            .then(result => setTodo(result))
            .catch(e => console.log(e));
    }, [id]);

    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setTodo(values => ({ ...values, [name]: value }));
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        const todoData = JSON.stringify(todo);
        fetch(`http://localhost:5273/api/Todo/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: todoData
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to update todo item');
                }
                return response.json();
            })
            .then(() => {
                alert('Todo item updated successfully');
                navigate('/');
            })
            .catch(error => {
                console.error('Error:', error);
            });
    };
    
    return (
        <Container>
            <Row className="justify-content-md-center">
                <Col xs={12} md={6}>
                    <h2 className="my-4 text-center">Update Todo</h2>
                    <Form onSubmit={handleSubmit}>
                        <Form.Group controlId="formId">
                            <Form.Label>Id:</Form.Label>
                            <Form.Control
                                type="text"
                                name="id"
                                value={todo.id ?? ""}
                                disabled={true}
                                onChange={handleChange}
                            />
                        </Form.Group>
                        <Form.Group controlId="formTitle">
                            <Form.Label>Title:</Form.Label>
                            <Form.Control
                                type="text"
                                name="title"
                                value={todo.title ?? ""}
                                onChange={handleChange}
                            />
                        </Form.Group>
                        <Form.Group controlId="formIsComplete">
                            <Form.Check
                                type="checkbox"
                                label="Is Complete"
                                name="isComplete"
                                checked={todo.isComplete ?? false}
                                onChange={e => setTodo(values => ({ ...values, isComplete: e.target.checked }))}
                            />
                        </Form.Group>
                        <Form.Group controlId="formPriority">
                            <Form.Label>Priority:</Form.Label>
                            <Form.Control
                                as="select"
                                name="priorityId"
                                value={todo.priorityId ?? 1}
                                onChange={handleChange}
                            >
                                <option value={1}>High</option>
                                <option value={2}>Medium</option>
                                <option value={3}>Low</option>
                            </Form.Control>
                        </Form.Group>
                        <Form.Group controlId="formCategory">
                            <Form.Label>Category:</Form.Label>
                            <Form.Control
                                as="select"
                                name="categoryId"
                                value={todo.categoryId ?? 1}
                                onChange={handleChange}
                            >
                                <option value={1}>Work</option>
                                <option value={2}>Personal</option>
                            </Form.Control>
                        </Form.Group>
                        <Button variant="primary" type="submit" className="mt-3">
                            Update Todo
                        </Button>
                    </Form>
                </Col>
            </Row>
        </Container>
    );
}

export default TodoUpdate;
