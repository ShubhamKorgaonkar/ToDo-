import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Container, Row, Col, Button, Card } from 'react-bootstrap';

function TodoDelete() {
    const [todo, setTodo] = useState({});
    const { id } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        fetch(`http://localhost:5273/api/Todo/${id}`)
            .then(res => res.json())
            .then(result => setTodo(result))
            .catch(e => console.log(e));
    }, [id]);
           
    const handleDelete = async () => {
        try {
            const response = await fetch(`http://localhost:5273/api/Todo/${id}`, {
                method: 'DELETE'
            });
            if (response.ok) {
                navigate('/');
                window.alert('Todo item deleted successfully.');
            } else {
                throw new Error('Failed to delete');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    const handleCancel = () => {
        navigate('/');
    };

    return (
        <Container className="mt-5">
            <Row className="justify-content-md-center">
                <Col md={6}>
                    <Card>
                        <Card.Body>
                            <Card.Title>ARE YOU SURE TO DELETE THIS?</Card.Title>
                            <Card.Text>ID: {todo.id}</Card.Text>
                            <Card.Text>Title: {todo.title}</Card.Text>
                            <Button variant="danger" onClick={handleDelete}>Delete</Button>
                            <Button variant="secondary" onClick={handleCancel} className="ms-2">Cancel</Button>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default TodoDelete;
