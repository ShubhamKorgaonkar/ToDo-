import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';

function TodoAdd() {
    const [title, setTitle] = useState('');
    const [isComplete, setIsComplete] = useState(false);
    const [priorityId, setPriorityId] = useState(1);
    const [categoryId, setCategoryId] = useState(1);
    const navigate = useNavigate();

    const handleAdd = async () => {
        try {
            const todoItemDto = {
                title,
                isComplete,
                priorityId,
                categoryId,
                created: new Date().toISOString()
            };
            alert("Todo added successfully");
            alert(JSON.stringify(todoItemDto, null, 2));
            
            const response = await fetch('http://localhost:5273/api/Todo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(todoItemDto)
            });
            if (!response.ok) {
                throw new Error('Failed to add todo item');
            }
            navigate('/'); // to homepage
           
        } catch (error) {
            console.error('Error adding todo item:', error);
        }
    };

    const handleCancel = () => {
        navigate('/'); // to home
    };

    return (
        <Container>
            <Row className="justify-content-md-center">
                <Col xs={12} md={6}>
                    <h1 className="my-4 text-center">Add New Todo</h1>
                    <Form onSubmit={(e) => { e.preventDefault(); handleAdd(); }}>
                        <Form.Group controlId="formTitle">
                            <Form.Label>Title:</Form.Label>
                            <Form.Control
                                type="text"
                                value={title}
                                onChange={(e) => setTitle(e.target.value)}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formIsComplete">
                            <Form.Check
                                type="checkbox"
                                label="Is Complete"
                                checked={isComplete}
                                onChange={(e) => setIsComplete(e.target.checked)}
                            />
                        </Form.Group>
                        <Form.Group controlId="formPriority">
                            <Form.Label>Priority:</Form.Label>
                            <Form.Control
                                as="select"
                                value={priorityId}
                                onChange={(e) => setPriorityId(parseInt(e.target.value, 10))}
                            >
                                <option value={1}>High</option>
                                <option value={2}>Medium</option>
                                <option value={3}>Low</option>
                            </Form.Control>
                        </Form.Group>
                        <Form.Group controlId="formCategory">
                            <Form.Label>Category:</Form.Label>
                            <Form.Control
                                as="select"
                                value={categoryId}
                                onChange={(e) => setCategoryId(parseInt(e.target.value, 10))}
                            >
                                <option value={1}>Work</option>
                                <option value={2}>Personal</option>
                            </Form.Control>
                        </Form.Group>
                        <Button variant="primary" type="submit" className="mt-3">
                            Add Todo
                        </Button>
                        <Button variant="secondary" className="mt-3 ms-2" onClick={handleCancel}>
                            Cancel
                        </Button>
                    </Form>
                </Col>
            </Row>
        </Container>
    );
}

export default TodoAdd;
