import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Container, Table, Form, Button, Alert } from "react-bootstrap";
import SearchBox from "./SearchBox";
import TodoListView from './TodoListView';

function TodoList() {
    const [todos, setTodos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [filteredTodos, setFilteredTodos] = useState([]);
    const [priorityFilter, setPriorityFilter] = useState('all');
    const [categoryFilter, setCategoryFilter] = useState('all');

    useEffect(() => {
        fetch("http://localhost:5273/api/Todo")
            .then(res => {
                if (!res.ok) {
                    throw new Error("Failed to fetch data");
                }
                return res.json();
            })
            .then(result => {
                setTodos(result);
                setFilteredTodos(result);
                setLoading(false);
            })
            .catch(err => {
                setError(err.message);
                setLoading(false);
            });
    }, []);

    const mapPriorityLabel = (priorityId) => {
        switch (priorityId) {
            case 1:
                return <span style={{ color: 'black' }}>High</span>;
            case 2:
                return <span style={{ color: 'black' }}>Medium</span>;
            case 3:
                return <span style={{ color: 'black' }}>Low</span>;
            default:
                return 'Unknown';
        }
    };

    const mapCategoryLabel = (categoryId) => {
        switch (categoryId) {
            case 1:
                return "Work";
            case 2:
                return "Personal";
            default:
                return "Unknown";
        }
    };
    const mapPriorityColor = (priorityId) => {
    switch (priorityId) {
        case 1:
            return '#da1e37'; 
        case 2:
            return '#ffea00'; 
        case 3:
            return '#009933'; 
        default:
            return 'white'; 
    }
};


    const handlePriorityFilterChange = (e) => {
        const value = e.target.value;
        setPriorityFilter(value);
        filterTodos(value, categoryFilter);
    };

    const handleCategoryFilterChange = (e) => {
        const value = e.target.value;
        setCategoryFilter(value);
        filterTodos(priorityFilter, value);
    };

    const filterTodos = (priority, category) => {
        let filtered = todos.filter(todo => {
            if (priority === 'all' && category === 'all') {
                return true;
            }
            if (priority === 'all' && category !== 'all') {
                return todo.categoryId.toString() === category;
            }
            if (priority !== 'all' && category === 'all') {
                return todo.priorityId.toString() === priority;
            }
            return todo.priorityId.toString() === priority && todo.categoryId.toString() === category;
        });
        setFilteredTodos(filtered);
    };

    return (
        <Container>
            <h4>
                <Link to="/create">Click here to add A new ToDo</Link>
            </h4>
            <h1>Todo List</h1>
            <div>
                <SearchBox todos={todos} setFilteredTodos={setFilteredTodos} />
                {loading ? (
                    <p>Loading...</p>
                ) : error ? (
                    <Alert variant="danger">{error}</Alert>
                ) : (
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Is Complete</th>
                                <th>Created</th>
                                <th>
                                    Priority:
                                    <Form.Select value={priorityFilter} onChange={handlePriorityFilterChange}>
                                        <option value="all">All</option>
                                        <option value="1">High</option>
                                        <option value="2">Medium</option>
                                        <option value="3">Low</option>
                                    </Form.Select>
                                </th>
                                <th>
                                    Category:
                                    <Form.Select value={categoryFilter} onChange={handleCategoryFilterChange}>
                                        <option value="all">All</option>
                                        <option value="1">Work</option>
                                        <option value="2">Personal</option>
                                    </Form.Select>
                                </th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredTodos.map(todo => (
                                <tr key={todo.id}>
                                    <td>{todo.id}</td>
                                    <td>{todo.title}</td>
                                    <td>{todo.isComplete ? "Yes" : "No"}</td>
                                    <td>{new Date(todo.created).toLocaleString()}</td>
                                    <td style={{ backgroundColor: mapPriorityColor(todo.priorityId) }}>
                                        {mapPriorityLabel(todo.priorityId)}
                                    </td>
                                    <td>{mapCategoryLabel(todo.categoryId)}</td>
                                    <td>
                                        <Link to={`/todo/edit/${todo.id}`}>Edit</Link>{" | "}
                                        <Link to={`/todo/delete/${todo.id}`}>Delete</Link>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                )}
            </div>
            <br />
            <div>
                <TodoListView />
            </div>
        </Container>
    );
}

export default TodoList;
