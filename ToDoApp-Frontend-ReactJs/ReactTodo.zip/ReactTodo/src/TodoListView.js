import React, { useState } from 'react';
import { Container, Row, Col, Form, Alert, ListGroup } from 'react-bootstrap';

function TodoListView() {
  const [todos, setTodos] = useState([]);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState('all'); //all work personal

  const fetchTodos = async (category) => {
    try {
      const response = await fetch(`http://localhost:5273/api/Todo/category/${category}`);
      if (!response.ok) {
        throw new Error();
      }
      const data = await response.json();
      setTodos(data);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleFilterChange = (event) => {
    const category = event.target.value;
    setFilter(category);
    fetchTodos(category === 'work' ? 1 : category === 'personal' ? 2 : '');
  };


  const mapPriorityLabel = (priorityId) => {
    switch (priorityId) {
      case 1:
        return 'High';
      case 2:
        return 'Medium';
      case 3:
        return 'Low';
      default:
        return 'Unknown';
    }
  };

  return (
    <Container>
      <Row className="my-3">
        <Col>
          <h3>View Todos By Category</h3>
          <Form.Group controlId="filterCategory">
            <Form.Label>Select Category</Form.Label>
            <Form.Control as="select" value={filter} onChange={handleFilterChange}>
              <option value="work">View Work Todos</option>
              <option value="personal">View Personal Todos</option>
            </Form.Control>
          </Form.Group>
        </Col>
      </Row>
      <Row>
        <Col>
          {error && <Alert variant="danger">{error}</Alert>}
          <ListGroup>
            {todos.map(todo => (
              <ListGroup.Item key={todo.id}>
                {todo.title} - {todo.isComplete ? 'Completed' : 'Pending'} - Priority: {mapPriorityLabel(todo.priorityId)}
              </ListGroup.Item>
            ))}
          </ListGroup>
        </Col>
      </Row>
    </Container>
  );
}

export default TodoListView;
