import React, { useState } from 'react';

function ViewPersonalTodos() {
  const [todos, setTodos] = useState([]);
  const [error, setError] = useState(null);

  const fetchPersonalTodos = async () => {
    try {
      const response = await fetch('http://localhost:5273/api/Todo/category/2'); 
      if (!response.ok) {
        throw new Error('Failed to fetch');
      }
      const data = await response.json();
      setTodos(data);
    } catch (err) {
      setError(err.message);
    }
  };

  // Function to map priority IDs to labels
  const mapPriorityLabel = (priorityId) => {
    switch (priorityId) {
      case 1:
        return 'High';
      case 2:
        return 'Medium';
      case 3:
        return 'Low';
      default:
        return 'Unknown';
    }
  };

  return (
    <div>
      <button onClick={fetchPersonalTodos}>View Personal Todos</button>
      {error && <p>{error}</p>}
      <ul>
        {todos.map(todo => (
          <li key={todo.id}>
            {todo.title} - {todo.isComplete ? 'Completed' : 'Pending'} - Priority: {mapPriorityLabel(todo.priorityId)}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ViewPersonalTodos;
