import React, { useState, useEffect } from "react";
import ViewWorkTodos from './ViewWorkTodos';
import ViewPersonalTodos from './ViewPersonalTodos';
import { Link } from "react-router-dom";
import SearchBox from "./SearchBox";

function TodoList() {
    const [todos, setTodos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [filteredTodos, setFilteredTodos] = useState([]);

    useEffect(() => {
        fetch("http://localhost:5273/api/Todo")
            .then(res => {
                if (!res.ok) {
                    throw new Error("Failed to fetch data");
                }
                return res.json();
            })
            .then(result => {
                setTodos(result);
                setFilteredTodos(result);
                setLoading(false);
            })
            .catch(err => {
                setError(err.message);
                setLoading(false);
            });
    }, []);

    // Function to map priority IDs to labels
    const mapPriorityLabel = (priorityId) => {
        switch (priorityId) {
            case 1:
                return "High";
            case 2:
                return "Medium";
            case 3:
                return "Low";
            default:
                return "Unknown";
        }
    };

    // Function to map category IDs to labels
    const mapCategoryLabel = (categoryId) => {
        switch (categoryId) {
            case 1:
                return "Work";
            case 2:
                return "Personal";
            default:
                return "Unknown";
        }
    };

    return (
        <div>
            <h4><Link to="/create">Click Here To Add New ToDo</Link></h4>
            <h1>Todo List</h1>
            <div>
                <SearchBox todos={todos} setFilteredTodos={setFilteredTodos} />
                {loading ? (
                    <p>Loading...</p>
                ) : error ? (
                    <p>Error: {error}</p>
                ) : (
                    <table>
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Is Complete</th>
                                <th>Created</th>
                                <th>Priority</th>
                                <th>Category</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredTodos.map(todo => (
                                <tr key={todo.id}>
                                    <td>{todo.id}</td>
                                    <td>{todo.title}</td>
                                    <td>{todo.isComplete ? "Yes" : "No"}</td>
                                    <td>{new Date(todo.created).toLocaleString()}</td>
                                    <td>{mapPriorityLabel(todo.priorityId)}</td>
                                    <td>{mapCategoryLabel(todo.categoryId)}</td>
                                    <td>
                                        <Link to={`/todo/edit/${todo.id}`}>Edit</Link>{" | "}
                                        <Link to={`/todo/delete/${todo.id}`}>Delete</Link>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>

            <div>
                <h1>Work Todo List</h1>
                <ViewWorkTodos />
            </div>
            <div>
                <h1>Personal Todo List</h1>
                <ViewPersonalTodos />
            </div>

        </div>
    );
}

export default TodoList;
