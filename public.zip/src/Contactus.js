import React from 'react';

export default function Contactus() {
    return (
        <div>
            <h1>Contact Us</h1>
            <p>
                Name : Shubham Vasant Korgaonkar
                Phone: +91 9029549876 <br />
                Email: <a href="mailto:9029549876sk@gmail.com">9029549876sk@gmail.com</a> <br />
                Address: 1303, Aardhya one earth, Ghatkopar - Avenue, tower- 4 Delta, Naidu colony, Ghatkopar (East) Pincode - 400075
            </p>
        </div>
    );
}
