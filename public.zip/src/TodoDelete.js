import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

function TodoDelete() {
    const [todo, setTodo] = useState({});
    const { id } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        fetch(`http://localhost:5273/api/Todo/${id}`)
            .then(res => res.json())
            .then(result => setTodo(result));
    }, [id]);

    const handleDelete = async () => {
        try {
            const response = await fetch(`http://localhost:5273/api/Todo/${id}`, {
                method: 'DELETE'
            });
            if (response.ok) {
                navigate('/');
            } else {
                throw new Error('Failed to delete');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    const handleCancel = () => {
        navigate('/');
    };

    return (
        <div>
            <h1>ARE YOU SURE TO DELETE THIS TODO?</h1>
            <p>ID: {todo.id}</p>
            <p>Title: {todo.title}</p>
            <p>Description: {todo.description}</p>
            <button onClick={handleDelete}>Delete</button>
            <button onClick={handleCancel}>Cancel</button>
        </div>
    );
}

export default TodoDelete;
