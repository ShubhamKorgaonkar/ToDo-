import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import SearchBox from "./SearchBox";
import TodoListView from './TodoListView';


function TodoList() {
    const [todos, setTodos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [filteredTodos, setFilteredTodos] = useState([]);
    const [priorityFilter, setPriorityFilter] = useState('all');
    const [categoryFilter, setCategoryFilter] = useState('all');

    useEffect(() => {
        fetch("http://localhost:5273/api/Todo")
            .then(res => {
                if (!res.ok) {
                    throw new Error("Failed to fetch data");
                }
                return res.json();
            })
            .then(result => {
                setTodos(result);
                setFilteredTodos(result);
                setLoading(false);
            })
            .catch(err => {
                setError(err.message);
                setLoading(false);
            });
    }, []);

    // Function to map priority IDs to labels
    const mapPriorityLabel = (priorityId) => {
        switch (priorityId) {
            case 1:
                return "High";
            case 2:
                return "Medium";
            case 3:
                return "Low";
            default:
                return "Unknown";
        }
    };

    // Function to map category IDs to labels
    const mapCategoryLabel = (categoryId) => {
        switch (categoryId) {
            case 1:
                return "Work";
            case 2:
                return "Personal";
            default:
                return "Unknown";
        }
    };

    const handlePriorityFilterChange = (e) => {
        setPriorityFilter(e.target.value);
        filterTodos(e.target.value, categoryFilter);
    };

    const handleCategoryFilterChange = (e) => {
        setCategoryFilter(e.target.value);
        filterTodos(priorityFilter, e.target.value);
    };

    const filterTodos = (priority, category) => {
        let filtered = todos.filter(todo => {
            if (priority === 'all' && category === 'all') {
                return true;
            }
            if (priority === 'all' && category !== 'all') {
                return todo.categoryId.toString() === category;
            }
            if (priority !== 'all' && category === 'all') {
                return todo.priorityId.toString() === priority;
            }
            return todo.priorityId.toString() === priority && todo.categoryId.toString() === category;
        });
        setFilteredTodos(filtered);
    };
    
    

    return (
        <div>
            <h4><Link to="/create">Click Here To Add New ToDo</Link></h4>
            <h1>Todo List</h1>
            <div>
                <SearchBox todos={todos} setFilteredTodos={setFilteredTodos} />
                {loading ? (
                    <p>Loading...</p>
                ) : error ? (
                    <p>Error: {error}</p>
                ) : (
                    <table>
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Is Complete</th>
                                <th>Created</th>
                                <th>
                                    Priority:
                                    <select value={priorityFilter} onChange={handlePriorityFilterChange}>
                                        <option value="all">All</option>
                                        <option value="1">High</option>
                                        <option value="2">Medium</option>
                                        <option value="3">Low</option>
                                    </select>
                                </th>
                                <th>
                                    Category:
                                    <select value={categoryFilter} onChange={handleCategoryFilterChange}>
                                        <option value="all">All</option>
                                        <option value="1">Work</option>
                                        <option value="2">Personal</option>
                                    </select>
                                </th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredTodos.map(todo => (
                                <tr key={todo.id}>
                                    <td>{todo.id}</td>
                                    <td>{todo.title}</td>
                                    <td>{todo.isComplete ? "Yes" : "No"}</td>
                                    <td>{new Date(todo.created).toLocaleString()}</td>
                                    <td>{mapPriorityLabel(todo.priorityId)}</td>
                                    <td>{mapCategoryLabel(todo.categoryId)}</td>
                                    <td>
                                        <Link to={`/todo/edit/${todo.id}`}>Edit</Link>{" | "}
                                        <Link to={`/todo/delete/${todo.id}`}>Delete</Link>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
            <br />
            <div>
                <TodoListView />
            </div>

        </div>
    );
}

export default TodoList;
