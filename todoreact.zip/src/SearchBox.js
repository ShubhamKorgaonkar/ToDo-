import React, { useState } from 'react';

function SearchBox({ todos, setFilteredTodos }) {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (e) => {
    const searchTerm = e.target.value.toLowerCase();
    setSearchTerm(searchTerm);
    const filteredTodos = todos.filter(todo =>
      todo.title.toLowerCase().includes(searchTerm)
    );
    setFilteredTodos(filteredTodos);
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Search Todo by Title..."
        value={searchTerm}
        onChange={handleSearch}
      />
    </div>
  );
}

export default SearchBox;
