import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './TodoAdd.css';

function TodoAdd() {
    const [title, setTitle] = useState('');
   
    const [isComplete, setIsComplete] = useState(false);
    const [priorityId, setPriorityId] = useState(1);
    const [categoryId, setCategoryId] = useState(1);
    const navigate = useNavigate();

    const handleAdd = async () => {
        try {
            const todoItemDto = {
                title,

                isComplete,
                priorityId,
                categoryId,
                created: new Date().toISOString()
            };
            alert("Todo added successfully");
            alert(JSON.stringify(todoItemDto, null, 2));
            
            const response = await fetch('http://localhost:5273/api/Todo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(todoItemDto)
            });
            if (!response.ok) {
                throw new Error('Failed to add todo item');
            }
            navigate('/'); // Navigate to the homepage or wherever is appropriate
           
        } catch (error) {
            console.error('Error adding todo item:', error);
        }
    };

    const handleCancel = () => {
        navigate('/'); // Navigate back to home or list page
    };

    return (
        <div>
            <h1>Add New Todo</h1>
            <form onSubmit={(e) => { e.preventDefault(); handleAdd(); }}>
                <div>
                    <label>Title:</label>
                    <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} required />
                </div>
    
                <div>
                    <label>Is Complete:</label>
                    <input type="checkbox" checked={isComplete} onChange={(e) => setIsComplete(e.target.checked)} />
                </div>
                <div>
                    <label>Priority:</label>
                    <select value={priorityId} onChange={(e) => setPriorityId(parseInt(e.target.value, 10))}>
                        <option value={1}>High</option>
                        <option value={2}>Medium</option>
                        <option value={3}>Low</option>
                    </select>
                </div>
                <div>
                    <label>Category:</label>
                    <select value={categoryId} onChange={(e) => setCategoryId(parseInt(e.target.value, 10))}>
                        <option value={1}>Work</option>
                        <option value={2}>Personal</option>
                    </select>
                </div>
                <button type="submit">Add Todo</button>
                <button type="button" onClick={handleCancel}>Cancel</button>
            </form>
        </div>
    );
}

export default TodoAdd;
