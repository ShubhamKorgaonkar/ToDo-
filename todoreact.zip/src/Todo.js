import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

export default function Todo() {
    const [todo, setTodo] = useState({});
    const { id } = useParams();

    useEffect(() => {
        fetch("http://localhost:5273/api/Todo" + id)
            .then(res => {
                if (!res.ok) {
                    throw new Error('Network response was not ok');
                }
                return res.json();
            })
            .then(result => {
                setTodo(result);
            })
            .catch(error => {
                console.error('Error fetching todo:', error);
            });
    }, [id]);

    return (
        <div>
            <label>Id:</label> {todo.id}<br />
            <label>Title:</label> {todo.title}<br />
            <label>Is Complete:</label> {todo.isComplete ? 'Yes' : 'No'}<br />
            <label>Created:</label> {todo.created}<br />
            <label>Priority:</label> {todo.priority}<br />
            <label>Category:</label> {todo.category}
        </div>
    );
}
